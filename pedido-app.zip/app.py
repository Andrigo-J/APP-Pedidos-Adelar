from flask import Flask, request, jsonify, render_template
import json

app = Flask(__name__)
ARQUIVO = 'pedidos.json'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/pedido', methods=['POST'])
def receber_pedido():
    pedido = request.get_json()
    try:
        with open(ARQUIVO, 'r') as f:
            pedidos = json.load(f)
    except FileNotFoundError:
        pedidos = []

    pedidos.append(pedido)

    with open(ARQUIVO, 'w') as f:
        json.dump(pedidos, f, indent=4)

    return jsonify({"mensagem": "Pedido recebido com sucesso!"})

if __name__ == '__main__':
    app.run(debug=True)
