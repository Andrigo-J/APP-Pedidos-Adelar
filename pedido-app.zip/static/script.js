document.getElementById('pedido-form').addEventListener('submit', function (e) {
  e.preventDefault();

  const dados = {
    funcionario: e.target.funcionario.value,
    produto: e.target.produto.value,
    quantidade: e.target.quantidade.value
  };

  fetch('/api/pedido', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  })
  .then(res => res.json())
  .then(data => alert(data.mensagem));
});
